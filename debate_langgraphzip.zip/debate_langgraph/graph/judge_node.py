class JudgeNode:
    def evaluate(self, memory):
        scientist_score = sum(
            1 for t in memory["turns"]
            if t["agent"] == "Scientist"
        )
        philosopher_score = 8 - scientist_score

        winner = "Scientist" if scientist_score >= philosopher_score else "Philosopher"

        summary = "Structured debate on regulation vs freedom."
        reason = "Scientist provided risk-based reasoning."

        return {
            "summary": summary,
            "winner": winner,
            "reason": reason
        }
