import random

class DebateAgent:
    def __init__(self, name, persona):
        self.name = name
        self.persona = persona

    def respond(self, topic, memory):
        prompt = f"""
Topic: {topic}
Persona: {self.persona}

Opponent arguments:
{memory}

Respond with a new argument.
"""
        # Stubbed LLM call (replace with OpenAI / Claude / etc.)
        return f"{self.name} argues from persona perspective."
