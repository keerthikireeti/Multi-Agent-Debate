"""
seed.py
---------------------------------
Centralized random seed control for deterministic
and reproducible debate runs.

Used by:
- Agent response generation
- Any randomized selection logic
- Testing & debugging
"""

import os
import random

try:
    import numpy as np
except ImportError:
    np = None


def set_seed(config: dict) -> None:
    """
    Initialize deterministic behavior across the system.

    Args:
        config (dict): Loaded config.yaml content
    """

    randomness_cfg = config.get("randomness", {})
    deterministic = randomness_cfg.get("deterministic", False)

    if not deterministic:
        return

    seed = randomness_cfg.get("seed", 0)

    # Python standard random
    random.seed(seed)

    # NumPy (if available)
    if np is not None:
        np.random.seed(seed)

    # Environment variable (useful for some LLM SDKs)
    os.environ["PYTHONHASHSEED"] = str(seed)

    print(f"[Seed] Deterministic mode enabled (seed={seed})")
