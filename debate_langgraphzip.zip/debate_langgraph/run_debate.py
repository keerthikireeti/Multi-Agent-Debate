topic = input("Enter topic for debate: ")

print("Starting debate between Scientist and Philosopher...")

for _ in range(8):
    agent, round_no = coordinator.next_turn()
    memory_slice = memory.get_relevant(agent)
    response = agents[agent].respond(topic, memory_slice)

    memory.update(round_no, agent, response, {"coherence": "ok"})
    logger.log({"round": round_no, "agent": agent, "text": response})

print("[Judge]")
result = judge.evaluate(memory.state)
print(result)
