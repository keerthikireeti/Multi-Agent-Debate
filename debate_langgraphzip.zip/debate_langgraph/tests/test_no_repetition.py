assert is_duplicate("AI is risky", ["AI is risky"]) is True
