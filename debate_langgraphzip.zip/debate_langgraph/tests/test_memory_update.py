"""
test_memory_update.py
---------------------------------
Tests for MemoryNode update and retrieval logic.

Covers:
- Memory insertion after each round
- Correct structure of stored turns
- Agent-specific memory slicing
"""

import pytest
from graph.memory_node import MemoryNode


@pytest.fixture
def config():
    """Minimal config required for MemoryNode"""
    return {
        "memory": {
            "opponent_turns_visible": 2,
            "store_full_transcript": True
        }
    }


@pytest.fixture
def memory_node(config):
    return MemoryNode(config)


def test_memory_updates_after_each_turn(memory_node):
    """
    Ensure memory updates correctly after each debate turn.
    """
    memory_node.update(
        round_no=1,
        agent="Scientist",
        text="AI should be regulated for safety.",
        meta={"coherence": "ok"}
    )

    assert len(memory_node.state["turns"]) == 1

    turn = memory_node.state["turns"][0]
    assert turn["round"] == 1
    assert turn["agent"] == "Scientist"
    assert turn["text"] == "AI should be regulated for safety."
    assert turn["meta"]["coherence"] == "ok"


def test_multiple_turns_are_stored(memory_node):
    """
    Ensure multiple turns are appended, not overwritten.
    """
    memory_node.update(1, "Scientist", "Argument A", {})
    memory_node.update(2, "Philosopher", "Argument B", {})

    assert len(memory_node.state["turns"]) == 2
    assert memory_node.state["turns"][1]["agent"] == "Philosopher"


def test_agent_specific_memory_slice(memory_node):
    """
    Ensure agents only receive opponent arguments,
    and only the configured number of recent turns.
    """
    memory_node.update(1, "Scientist", "Scientist Arg 1", {})
    memory_node.update(2, "Philosopher", "Philosopher Arg 1", {})
    memory_node.update(3, "Scientist", "Scientist Arg 2", {})
    memory_node.update(4, "Philosopher", "Philosopher Arg 2", {})

    # Scientist should see only Philosopher's last arguments
    scientist_view = memory_node.get_relevant("Scientist")

    assert len(scientist_view) == 2
    assert all(turn["agent"] == "Philosopher" for turn in scientist_view)

    # Philosopher should see only Scientist's last arguments
    philosopher_view = memory_node.get_relevant("Philosopher")

    assert len(philosopher_view) == 2
    assert all(turn["agent"] == "Scientist" for turn in philosopher_view)


def test_memory_does_not_expose_self_arguments(memory_node):
    """
    Ensure an agent never sees its own arguments in memory slice.
    """
    memory_node.update(1, "Scientist", "Scientist Arg", {})
    memory_node.update(2, "Philosopher", "Philosopher Arg", {})

    scientist_view = memory_node.get_relevant("Scientist")

    for turn in scientist_view:
        assert turn["agent"] != "Scientist"
