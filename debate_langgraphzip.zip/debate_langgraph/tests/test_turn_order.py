def test_turns():
    coord = Coordinator()
    assert coord.next_turn()[0] == "Scientist"
    assert coord.next_turn()[0] == "Philosopher"
