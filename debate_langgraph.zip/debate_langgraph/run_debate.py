import argparse
import os
import time
from graph.debate_nodes import DebateWorkflow


def main():
    parser = argparse.ArgumentParser(description="Run a structured debate between two AI personas.")
    parser.add_argument("--seed", type=int, default=None, help="Optional random seed for determinism")
    parser.add_argument("--log-path", type=str, default=None, help="Path to write the log file")
    parser.add_argument("--topic", type=str, default=None, help="Provide topic on CLI to run non-interactively")
    parser.add_argument("--scientist-persona", type=str, default="personas/scientist.txt")
    parser.add_argument("--philosopher-persona", type=str, default="personas/philosopher.txt")
    args = parser.parse_args()

    # Get topic from CLI or prompt the user
    if args.topic:
        topic = args.topic.strip()
    else:
        topic = input("Enter topic for debate: ").strip()

    if len(topic) < 5:
        print("Topic too short. Please provide a longer topic.")
        return

    # sanitize topic (basic)
    topic = topic.replace("\n", " ")[:2000]

    timestamp = int(time.time())
    log_path = args.log_path or os.path.join("logs", f"debate_log_{timestamp}.jsonl")

    persona_paths = {"Scientist": args.scientist_persona, "Philosopher": args.philosopher_persona}
    os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)

    wf = DebateWorkflow(topic=topic, persona_paths=persona_paths, log_path=log_path, seed=args.seed)
    result = wf.run()

    print(f"Log written to: {log_path}")


if __name__ == "__main__":
    main()
