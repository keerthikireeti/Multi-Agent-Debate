"""
validation.py
---------------------------------
Validation utilities for the LangGraph Debate System.

Responsibilities:
- Detect repeated or semantically similar arguments
- Detect topic drift
- Detect basic logical contradictions
- Return structured validation metadata for logging
"""

from difflib import SequenceMatcher
from typing import List, Dict


# -------------------------------
# STRING SIMILARITY (REPETITION)
# -------------------------------

def similarity_ratio(text1: str, text2: str) -> float:
    """
    Compute similarity ratio between two strings.
    Uses SequenceMatcher for lightweight semantic comparison.
    """
    return SequenceMatcher(None, text1.lower(), text2.lower()).ratio()


def detect_repetition(
    new_text: str,
    previous_texts: List[str],
    threshold: float
) -> bool:
    """
    Detect whether new_text is a repeated or near-duplicate argument.

    Args:
        new_text (str): Newly generated argument
        previous_texts (List[str]): Past debate arguments
        threshold (float): Similarity threshold from config

    Returns:
        bool: True if repetition detected, else False
    """
    for past in previous_texts:
        if similarity_ratio(new_text, past) >= threshold:
            return True
    return False


# -------------------------------
# TOPIC DRIFT DETECTION
# -------------------------------

def detect_topic_drift(
    text: str,
    topic: str,
    max_drift_ratio: float
) -> bool:
    """
    Detect whether an argument drifts too far from the debate topic.

    Method:
    - Token overlap ratio between argument and topic
    - If overlap is too low, flag as drift

    Returns:
        bool: True if topic drift detected
    """
    topic_tokens = set(topic.lower().split())
    text_tokens = set(text.lower().split())

    if not topic_tokens:
        return False

    overlap_ratio = len(topic_tokens & text_tokens) / len(topic_tokens)
    return overlap_ratio < max_drift_ratio


# -------------------------------
# CONTRADICTION DETECTION (BASIC)
# -------------------------------

def detect_contradiction(
    new_text: str,
    previous_texts: List[str]
) -> bool:
    """
    Lightweight contradiction detection.

    Strategy:
    - Looks for explicit negation conflicts
    - Example: "AI should be regulated" vs "AI should not be regulated"

    Returns:
        bool: True if contradiction detected
    """
    negations = {"not", "never", "no", "cannot", "shouldn't"}

    new_tokens = set(new_text.lower().split())

    for past in previous_texts:
        past_tokens = set(past.lower().split())

        shared_tokens = new_tokens & past_tokens
        negation_conflict = (
            shared_tokens
            and (
                (negations & new_tokens) ^ (negations & past_tokens)
            )
        )

        if negation_conflict:
            return True

    return False


# -------------------------------
# FULL VALIDATION PIPELINE
# -------------------------------

def validate_argument(
    *,
    new_text: str,
    topic: str,
    previous_texts: List[str],
    config: Dict
) -> Dict:
    """
    Run all validation checks on a debate argument.

    Returns structured metadata for logging & memory storage.
    """

    repetition = detect_repetition(
        new_text,
        previous_texts,
        config["validation"]["repetition_similarity_threshold"]
    )

    topic_drift = detect_topic_drift(
        new_text,
        topic,
        config["validation"]["topic_drift_max_ratio"]
    )

    contradiction = False
    if config["validation"]["enable_contradiction_check"]:
        contradiction = detect_contradiction(new_text, previous_texts)

    valid = not (repetition or topic_drift or contradiction)

    return {
        "valid": valid,
        "repetition": repetition,
        "topic_drift": topic_drift,
        "contradiction": contradiction
    }
