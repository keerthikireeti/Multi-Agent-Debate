class Coordinator:
    def __init__(self):
        self.current_round = 0
        self.expected_agent = "Scientist"

    def next_turn(self):
        if self.current_round >= 8:
            raise RuntimeError("Debate already finished")

        self.current_round += 1
        agent = self.expected_agent
        self.expected_agent = (
            "Philosopher" if agent == "Scientist" else "Scientist"
        )
        return agent, self.current_round
