class MemoryNode:
    def __init__(self):
        self.state = {"turns": [], "summary": ""}

    def update(self, round_no, agent, text, meta):
        self.state["turns"].append({
            "round": round_no,
            "agent": agent,
            "text": text,
            "meta": meta
        })

    def get_relevant(self, agent):
        return [
            t for t in self.state["turns"]
            if t["agent"] != agent
        ][-2:]
