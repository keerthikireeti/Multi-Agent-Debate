import time
import json
import os
import random
import difflib
import hashlib
from typing import List, Dict, Any, Optional

try:
    import graphviz
    HAS_GRAPHVIZ = True
except Exception:
    HAS_GRAPHVIZ = False


def _now_ts():
    return time.time()


class Coordinator:
    def __init__(self, start_agent: str = "Scientist", max_rounds: int = 8):
        self.current_round = 0
        self.expected_agent = start_agent
        self.max_rounds = max_rounds

    def next_turn(self):
        if self.current_round >= self.max_rounds:
            raise RuntimeError("Debate already finished")

        self.current_round += 1
        agent = self.expected_agent
        # flip expected agent
        self.expected_agent = (
            "Philosopher" if agent == "Scientist" else "Scientist"
        )
        return agent, self.current_round


class MemoryNode:
    def __init__(self):
        self.state: Dict[str, Any] = {"turns": [], "summary": ""}

    def update(self, round_no: int, agent: str, text: str, meta: Dict[str, Any]):
        entry = {"round": round_no, "agent": agent, "text": text, "meta": meta}
        self.state["turns"].append(entry)

    def get_relevant(self, agent: str) -> Dict[str, Any]:
        # Return only opponent's last two turns and a short summary
        opponent = "Philosopher" if agent == "Scientist" else "Scientist"
        opp_turns = [t for t in self.state["turns"] if t["agent"] == opponent]
        relevant = {"turns": opp_turns[-2:], "summary": self.state.get("summary", "")}
        return relevant

    def snapshot(self) -> Dict[str, Any]:
        return json.loads(json.dumps(self.state))


class Logger:
    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)

    def log(self, event_type: str, payload: Dict[str, Any]):
        ev = {"timestamp": _now_ts(), "type": event_type, "payload": payload}
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(ev, ensure_ascii=False) + "\n")


class JudgeNode:
    def evaluate(self, memory: Dict[str, Any]) -> Dict[str, Any]:
        turns = memory.get("turns", [])
        scores = {"Scientist": 0, "Philosopher": 0}
        issues: List[str] = []

        for t in turns:
            agent = t["agent"]
            meta = t.get("meta", {})
            # coherence score
            if meta.get("coherence") == "ok":
                scores[agent] += 1
            if meta.get("drift"):
                issues.append(f"Drift in round {t['round']} by {agent}")
            if meta.get("repetition"):
                issues.append(f"Repetition in round {t['round']} by {agent}")

        # Tiebreaker: number of turns (same) -> prefer fewer issues
        scientist_score = scores["Scientist"]
        philosopher_score = scores["Philosopher"]

        if scientist_score > philosopher_score:
            winner = "Scientist"
        elif philosopher_score > scientist_score:
            winner = "Philosopher"
        else:
            # fewer issues wins
            s_issues = sum(1 for i in issues if "Scientist" in i)
            p_issues = sum(1 for i in issues if "Philosopher" in i)
            winner = "Scientist" if s_issues <= p_issues else "Philosopher"

        # summary: short concatenation of main claims
        lines = [f"[{t['agent']}] {t['text']}" for t in turns]
        summary = "\n".join(lines)
        reason = f"Winner chosen by coherence score and issue counts. Issues: {issues}" if issues else "Winner chosen by coherence score."

        return {"summary": summary, "winner": winner, "reason": reason}


class DebateAgent:
    def __init__(self, name: str, persona_text: str, rng: random.Random):
        self.name = name
        self.persona = persona_text.strip()
        self.rng = rng

    def respond(self, topic: str, memory: Dict[str, Any]) -> str:
        # Build an argument from persona cues + deterministic choices
        topic_clean = topic.strip().rstrip(".?")
        templates = []
        if "Scientist" in self.persona or "empirical" in self.persona.lower():
            templates = [
                f"From an empirical perspective, {topic_clean} raises measurable risks that require regulation.",
                f"Evidence suggests that aspects of {topic_clean} can cause harm without oversight.",
                f"A risk-based framework for {topic_clean} aligns with public safety and precedent in medicine."
            ]
        else:
            templates = [
                f"Considering values and freedom, {topic_clean} requires caution against overregulation.",
                f"Historically, restricting inquiry around {topic_clean} has slowed societal progress.",
                f"From an ethical standpoint, autonomy around {topic_clean} is paramount and must be protected."
            ]

        # incorporate opponent recent points if available
        opp_turns = memory.get("turns", [])
        reply_parts = []
        if opp_turns:
            last = opp_turns[-1]["text"]
            reply_parts.append(f"Responding to: '{last}'")

        choice = self.rng.choice(templates)
        reply_parts.append(choice)

        # append a small deterministic justification fragment
        facts = ["studies", "historical cases", "ethical principles", "risk assessment"]
        reply_parts.append(f"(Justification: {self.rng.choice(facts)})")

        return " ".join(reply_parts)


def _normalize_text(t: str) -> str:
    return " ".join(t.lower().split())


def is_repetition(candidate: str, previous_texts: List[str], threshold: float = 0.75) -> bool:
    cand = _normalize_text(candidate)
    for p in previous_texts:
        pnorm = _normalize_text(p)
        # exact containment
        if cand in pnorm or pnorm in cand:
            return True
        ratio = difflib.SequenceMatcher(None, cand, pnorm).ratio()
        if ratio >= threshold:
            return True
    return False


def jaccard(a: str, b: str) -> float:
    sa = set(a.lower().split())
    sb = set(b.lower().split())
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


class DebateWorkflow:
    def __init__(self, topic: str, persona_paths: Dict[str, str], log_path: str, seed: Optional[int] = None, max_rounds: int = 8):
        self.topic = topic
        self.seed = seed if seed is not None else random.randint(0, 2**32 - 1)
        self.rng = random.Random(self.seed)
        self.coordinator = Coordinator(max_rounds=max_rounds)
        self.memory = MemoryNode()
        self.logger = Logger(log_path)
        self.judge = JudgeNode()
        self.max_rounds = max_rounds

        # load personas
        def _load(p):
            with open(p, encoding="utf-8") as f:
                return f.read()

        self.agents = {
            "Scientist": DebateAgent("Scientist", _load(persona_paths["Scientist"]), random.Random(self.rng.randint(0, 2**32 - 1))),
            "Philosopher": DebateAgent("Philosopher", _load(persona_paths["Philosopher"]), random.Random(self.rng.randint(0, 2**32 - 1)))
        }

        # log initial config
        self.logger.log("init", {"topic": self.topic, "seed": self.seed, "personas": persona_paths})

    def run(self):
        print(f"Starting debate between Scientist and Philosopher (seed={self.seed})...")
        rounds = []
        while True:
            try:
                agent_name, round_no = self.coordinator.next_turn()
            except RuntimeError:
                break

            # get relevant memory for this agent
            relevant = self.memory.get_relevant(agent_name)
            self.logger.log("turn_requested", {"round": round_no, "agent": agent_name, "relevant_memory": relevant})

            # agent generates response
            agent = self.agents[agent_name]
            response = agent.respond(self.topic, relevant)

            # repetition detection
            previous_texts = [t["text"] for t in self.memory.state["turns"]]
            rep = is_repetition(response, previous_texts)

            # coherence checks: topic drift
            drift_score = jaccard(response, self.topic)
            drift = drift_score < 0.15

            meta = {"coherence": "ok" if not drift and not rep else "issue", "repetition": rep, "drift": drift}

            # if repetition, modify response or reject and force a new reply attempt (max attempts)
            attempts = 0
            while rep and attempts < 3:
                # ask agent to rephrase deterministically
                response = agent.respond(self.topic, relevant) + " (rephrased)"
                rep = is_repetition(response, previous_texts)
                attempts += 1

            # final meta update
            meta["repetition"] = rep
            meta["drift"] = jaccard(response, self.topic) < 0.15

            # update memory and log
            self.memory.update(round_no, agent_name, response, meta)
            self.logger.log("turn_completed", {"round": round_no, "agent": agent_name, "text": response, "meta": meta})

            # print to stdout
            print(f"[Round {round_no}] {agent_name}: {response}")

            if self.coordinator.current_round >= self.max_rounds:
                break

        # final judge
        mem_snap = self.memory.snapshot()
        self.logger.log("memory_snapshot", mem_snap)
        result = self.judge.evaluate(mem_snap)
        self.logger.log("final_judgment", result)

        print("[Judge] Summary of debate:")
        print(result["summary"])
        print(f"[Judge] Winner: {result['winner']}\nReason: {result['reason']}")

        # generate DAG diagram if possible
        try:
            if HAS_GRAPHVIZ:
                dot = graphviz.Digraph("debate_dag")
                dot.node("Coordinator")
                dot.node("Memory")
                dot.node("Scientist")
                dot.node("Philosopher")
                dot.node("Judge")
                dot.node("Logger")
                dot.edges([("Coordinator", "Scientist"), ("Coordinator", "Philosopher"), ("Scientist", "Memory"), ("Philosopher", "Memory"), ("Memory", "Judge"), ("Judge", "Logger")])
                os.makedirs("diagrams", exist_ok=True)
                path = os.path.join("diagrams", f"debate_dag_{int(time.time())}.png")
                dot.render(path, format="png", cleanup=True)
                self.logger.log("dag_generated", {"path": path + ".png"})
        except Exception as e:
            self.logger.log("dag_error", {"error": str(e)})

        return result
