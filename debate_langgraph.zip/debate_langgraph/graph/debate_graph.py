from langgraph.graph import StateGraph

def build_graph():
    graph = StateGraph(dict)
    graph.add_node("Coordinator", ...)
    graph.add_node("Memory", ...)
    graph.add_node("Scientist", ...)
    graph.add_node("Philosopher", ...)
    graph.add_node("Judge", ...)
    graph.add_node("Logger", ...)
    return graph.compile()
