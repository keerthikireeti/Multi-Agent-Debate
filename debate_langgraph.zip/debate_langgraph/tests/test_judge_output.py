from graph.debate_nodes import DebateWorkflow


def test_judge_output(tmp_path):
    log = tmp_path / "log4.jsonl"
    persona_paths = {"Scientist": "personas/scientist.txt", "Philosopher": "personas/philosopher.txt"}
    wf = DebateWorkflow(topic="Should AI be regulated like medicine?", persona_paths=persona_paths, log_path=str(log), seed=99)
    result = wf.run()

    assert "winner" in result and "reason" in result
