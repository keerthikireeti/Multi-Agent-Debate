from graph.debate_nodes import DebateWorkflow
import os


def test_turn_order(tmp_path):
    log = tmp_path / "log.jsonl"
    persona_paths = {"Scientist": "personas/scientist.txt", "Philosopher": "personas/philosopher.txt"}
    wf = DebateWorkflow(topic="Should AI be regulated like medicine?", persona_paths=persona_paths, log_path=str(log), seed=42)
    result = wf.run()

    turns = wf.memory.state["turns"]
    assert len(turns) == 8
    for i, t in enumerate(turns):
        expected = "Scientist" if i % 2 == 0 else "Philosopher"
        assert t["agent"] == expected
def test_turns():
    coord = Coordinator()
    assert coord.next_turn()[0] == "Scientist"
    assert coord.next_turn()[0] == "Philosopher"
