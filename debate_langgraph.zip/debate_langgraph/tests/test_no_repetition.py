from graph.debate_nodes import DebateWorkflow


def test_no_repetition(tmp_path):
    log = tmp_path / "log2.jsonl"
    persona_paths = {"Scientist": "personas/scientist.txt", "Philosopher": "personas/philosopher.txt"}
    wf = DebateWorkflow(topic="Is AI a public good?", persona_paths=persona_paths, log_path=str(log), seed=123)
    wf.run()

    turns = wf.memory.state["turns"]
    # ensure none of the turns were flagged as repetition
    assert all(not t["meta"].get("repetition", False) for t in turns)
assert is_duplicate("AI is risky", ["AI is risky"]) is True
